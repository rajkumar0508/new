<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class customerImage extends Model
{
    protected $fillable = array('*');
}

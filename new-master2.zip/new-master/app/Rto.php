<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rto extends Model
{
    //
}

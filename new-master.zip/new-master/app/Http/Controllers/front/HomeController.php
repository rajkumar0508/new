<?php

namespace App\Http\Controllers\front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Hash;
use App\Company;
use App\Product;
use App\Youtube;
class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		
	   $course =  Company::get();
       return view('front.course.index')->with('course', $course);
    }
	public function lession(Request $request, $id)
	{
		 $data = Company::with('lession')->where('id', $id)->first();
		return view('front.lession.index')->with('data', $data);
	}
	public function videos(Request $request, $id)
	{
		 $data = Product::with('youtube')->where('id', $id)->first();
		 return view('front.youtube.index')->with('data', $data);
	}
	
}

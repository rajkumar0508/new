<?php

namespace App\Http\Controllers\front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Hash;
use Session;

class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('front.auth.register');
    }
	public function register(Request $request){
		  $validatedData = $request->validate([
			'name' => 'required',
            'email' => 'required|unique:users',
            'password' => ['required'],
            'mobile' => ['required'],
        ]); 
        $data = request()->except(['_token','_method']);
        $data['password'] = Hash::make($request['password']);
        User::insert($data);
		Session::flash('message', 'Successfully Registered! Please login to continue'); 
		return redirect()->back();
	}
	
}

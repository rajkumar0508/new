<?php $__env->startSection('content'); ?>
 <section class="sub-subject">
			<div class="container-fluid p-0">
                <div class="header-hard-menu my-3">
                    <p class="text-center text-white mb-0"><?php echo e($data->name); ?></p>
                </div>
				<div class="row">
					<?php $__currentLoopData = $data->lession; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $va=>$key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<div class="box">
                            <h6 class="text-center text-dark text-uppercase font-weight-bold"><a href="<?php echo e(URL::to('front/videos')); ?>/<?php echo e($key->id); ?>"><?php echo e($key->name); ?></a></h6>
                            <div class="mt-3 Description">
                                <p>Description :</p>
                                <p class="text-center"><?php echo e($key->description); ?></p>
                            </div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>	
	</section>
<?php $__env->stopSection(); ?>







  
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-master\resources\views/front/lession/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <section class="container subject-section">
        <div class="row">
		  <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $va=>$key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="box col-lg-4  mb-3 d-flex">

                <div class="card-body text-primary">
                    <a href="<?php echo e(URL::to('front/lession')); ?>/<?php echo e($key->id); ?>" class="card-title text-center"><?php echo e($key->name); ?></a>

                </div>
            </div> 
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>








  
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-master\resources\views/front/course/index.blade.php ENDPATH**/ ?>
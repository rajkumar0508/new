<?php $__env->startSection('content'); ?>
     <section class="sub-subject">		
			<div class="container-fluid p-0">
                <div class="header-hard-menu my-3">
                    <p class="text-center text-white mb-0"><?php echo e($data->name); ?></p>
                </div>
				<div class="row">
					<?php $__currentLoopData = $data->youtube; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $va=>$key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
							<div class="box">
								<iframe width="300" height="250" src="<?php echo e($key->youtube); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
							</div>							
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>	
	</section>
<?php $__env->stopSection(); ?>







  
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-master\resources\views/front/youtube/index.blade.php ENDPATH**/ ?>
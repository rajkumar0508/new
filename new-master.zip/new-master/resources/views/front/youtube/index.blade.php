@extends('layouts.website')
@section('content')
     <section class="sub-subject">		
			<div class="container-fluid p-0">
                <div class="header-hard-menu my-3">
                    <p class="text-center text-white mb-0">{{ $data->name }}</p>
                </div>
				<div class="row">
					@foreach($data->youtube as $va=>$key)
						<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
							<div class="box">
								<iframe width="300" height="250" src="{{ $key->youtube }}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
							</div>							
						</div>
					@endforeach
				</div>
			</div>	
	</section>
@endsection







  
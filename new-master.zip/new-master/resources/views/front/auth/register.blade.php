<!DOCTYPE html>
<html lang="en">

<head>
    <title>Learning</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="icon" href="images/logo-new.png" type="image/gif" sizes="16x16" />
    <link rel="stylesheet" type="text/css" href="{{ asset('front-css/bootstrap.min.css') }}" />
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;900&family=Montserrat:wght@100;200;300;400;500;600;700&family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet" />

    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"/>
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" />

    <link rel="stylesheet" type="text/css" href="{{ asset('front-css/style.css') }}" />
    
</head>

<style>
    .menu-dropdown-icon ul {
        display: flex;
        justify-content: space-evenly;
    }
	.alert-success {
    color: white;
    background-color: #28a745;
    border-color: #c3e6cb;
}
</style>

<body class="">
   
	<div class="container-fluid" style="height:100vh; background-image:linear-gradient(to right, rgb(248, 87, 166) 0%, rgb(255, 88, 88) 51%, rgb(248, 87, 166) 100%)">
		<div class="container">
			<h2 class="text-center text-white pt-3" id="title">Engineering Students Learning website</h2>
			
 			<hr>
			<div class="row mt-5">
				<div class="col-md-5">
				@if(Session::has('message'))
						 <div class="alert alert-success">
            {{ Session::get('message') }}
        </div>
				@endif
 					<form role="form" class="form-input-youtube" method="post" action="{{ URL::to('front/register') }}">
						<fieldset>							
							<p class="text-uppercase pull-center text-white "> SIGN UP.</p>	
 							<div class="form-group">
								<input type="text" name="name" value="{{ old('name')}}" id="username" class="form-control input-lg" placeholder="Username" required>
							</div>

							<div class="form-group">
								<input type="email" name="email" value="{{ old('email')}}" id="email" class="form-control input-lg" placeholder="Email Address" required>
								@if(old('mobile') != '')
									<p style="color:white;">{{ $errors->first('email') }}</p>
								@endif
							</div>
							<div class="form-group">
								<input type="password" name="password" id="password" minlength="8" class="form-control input-lg" placeholder="Password" required>
							</div>
								<div class="form-group">
								<input type="number" name="mobile" value="{{ old('mobile')}}" id="mobile" class="form-control input-lg" placeholder="Mobile number" required>
							
							</div>
							
							<div class="form-check">
								<label class="form-check-label text-white" style="font-size: 12px;">
								  <input type="checkbox" style="margin-top: 3px;" class="form-check-input " required>
								  By Clicking register you're agree to our policy & terms
								</label>
							  </div>
							 @csrf
							@method('POST')
 							<div class="mt-3 registerbutton">
 									 <button  type="submit" class="btn btn-lg btn-success"   value="Register">
                                        Register
                                      </button>
 							</div>
						</fieldset>
					</form>
				</div>
				
				<div class="col-md-2">
					<!-------null------>
				</div>
				
				<div class="col-md-5">
				
 				 		<form role="form" class="form-input-youtube" method="post" action="{{ URL::to('front/login') }}">
						<fieldset>							
							<p class="text-uppercase text-white"> Login using your account: </p>
											
							@if(old('mobile') == '')
 								<p style="color:gold;">{{ $errors->first('email') }}</p>
								<p style="color:gold;">{{ $errors->first('password') }}</p>
							@endif
							<div class="form-group">
								<input type="email" name="email" id="username" class="form-control input-lg" placeholder="Username" required>
							</div>
							<div class="form-group">
								<input type="password" name="password" id="password" class="form-control input-lg" placeholder="Password" required>
							</div>
							<div class="registerbutton">
                                <button type="submit" class="btn btn-success" value="Sign In">
                                    Sign In
                                </button>
								 @csrf
							@method('POST')
							</div>
								 
 						</fieldset>
				</form>	
				</div>
			</div>
		</div>
		
	</div>
  
  
 
  

    <script src="{{ asset('front-js/jquery.min.js') }}"></script>
    <script src="{{ asset('front-js/slick.js') }}"></script>
    <!-- <script src="js/slim.min.js"></script> -->
    <script src="{{ asset('front-js/popper.min.js') }}"></script>
    <script src="{{ asset('front-js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('front-js/custom.js') }}"></script>

   
</body>

</html>
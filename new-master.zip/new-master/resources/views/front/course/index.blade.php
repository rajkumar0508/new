@extends('layouts.website')
@section('content')
    <section class="container subject-section">
        <div class="row">
		  @foreach($course as $va=>$key)
            <div class="box col-lg-4  mb-3 d-flex">

                <div class="card-body text-primary">
                    <a href="{{ URL::to('front/lession') }}/{{ $key->id }}" class="card-title text-center">{{ $key->name}}</a>

                </div>
            </div> 
		  @endforeach
        </div>
    </section>
@endsection








  
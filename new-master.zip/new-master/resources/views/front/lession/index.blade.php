@extends('layouts.website')
@section('content')
 <section class="sub-subject">
			<div class="container-fluid p-0">
                <div class="header-hard-menu my-3">
                    <p class="text-center text-white mb-0">{{ $data->name }}</p>
                </div>
				<div class="row">
					@foreach($data->lession as $va=>$key)
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
						<div class="box">
                            <h6 class="text-center text-dark text-uppercase font-weight-bold"><a href="{{ URL::to('front/videos') }}/{{ $key->id }}">{{ $key->name }}</a></h6>
                            <div class="mt-3 Description">
                                <p>Description :</p>
                                <p class="text-center">{{ $key->description }}</p>
                            </div>
						</div>
					</div>
					@endforeach
				</div>
			</div>	
	</section>
@endsection







  